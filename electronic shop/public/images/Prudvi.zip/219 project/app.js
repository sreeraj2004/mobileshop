const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const Student = require('./Student');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public'));

mongoose.connect('mongodb://localhost:27017/ecommerce', {});

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});
app.get('/login', (req, res) => {
  res.send('This is the login page');
});
app.post('/signup', (req, res) => {
  const student = new Student({
    name: req.body.fname,
    lastName: req.body.lname,
    email: req.body.email,
    password: req.body.password
  });

  student.save((err) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error saving student');
    } else {
      res.redirect('/');
    }
  });
});

app.listen(3000, () => {
  console.log('Server started on port http://localhost:3000');
});