const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  name: String,
  lastName: String,
  email: String,
  password: String
});

module.exports = mongoose.model('Student', studentSchema);